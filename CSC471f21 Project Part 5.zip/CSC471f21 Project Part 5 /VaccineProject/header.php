

<nav class="navbar navbar-static-top navbar-inverse bg-inverse" style="paddding-left:100px; padding-right:100px;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbarSupportedContent">    
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>   
      </button>
      <a class="navbar-brand" href="index.php">Vaccine Dashboard</a>
    </div>
  </div>
</nav>

<style>
  .help-block{
    color:red;
  }
</style>